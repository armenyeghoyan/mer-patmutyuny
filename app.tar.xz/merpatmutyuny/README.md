# Մեր Պատմությունը — website

A Django + SQLite website for the «Մեր Պատմությունը» YouTube channel.

## Architecture

```
merpatmutyuny/
├── config/                 Python: Django settings and URLs
├── catalog/                Python: the app
│   ├── models.py           DB tables: Section, Episode, Short
│   ├── admin.py            Editor's panel at /admin
│   ├── views.py            Home page + JSON API at /api/catalog/
│   ├── utils.py            YouTube-link parsing, section suggestion
│   ├── data/initial.json   The 149 episodes, 5 sections and 6 Shorts
│   └── management/commands/
│       ├── seed_initial.py     fills an empty database
│       └── import_youtube.py   hourly import of new uploads
├── templates/catalog/index.html   HTML (page structure only)
├── static/css/site.css            design
├── static/js/site.js              behaviour (player, filters, animations)
├── deploy/                 gunicorn service, nginx config, cron line
└── db.sqlite3              the database (created on first run)
```

The flow: the **database** holds the content. The editor changes it in **/admin**.
**Python** reads it and puts it into the **HTML** page as JSON. **site.js** draws
the page from that JSON. Nobody edits HTML to add an episode.

## Run on your computer

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_initial
python manage.py createsuperuser        # your admin login
python manage.py runserver
```

The site is at http://127.0.0.1:8000. The admin panel is at http://127.0.0.1:8000/admin.

## The editor's weekly workflow (/admin)

* **New upload found automatically.** Every hour the server checks the channel.
  It adds new videos with the status **«Սպասում է ստուգման»** (waiting for
  review) and suggests a section. Open *Դրվագներ*, filter by that status, then
  set the section, tick *Գլխավոր էջում* if needed, and change the status to
  **Հրապարակված**. You can do all of this straight in the list and press *Save*.
* **Adding by hand.** Go to *Դրվագներ*, then *Ավելացնել*. Paste the YouTube
  link, and the ID is extracted automatically. The episode number is filled in
  for you. Pick a section and save.
* **Placement.**
  * *Բաժին* picks the section.
  * *Գլխավոր էջում* pins the episode to the top "this week" block.
  * *Առաջնահերթություն* pushes it up in lists (a bigger number goes higher).
* **Sections.** *Բաժիններ* lets you rename sections, add new ones, change their
  order and edit their *keywords*. The keywords drive the automatic section
  suggestion.
* **Shorts.** Shorts are managed in *Shorts* the same way.

To give the editor access, go to *Users*, then *Add*. Tick **Staff status** and
give permissions only for *Catalog* (Section, Episode, Short).

## Deploy on a Linux server (Ubuntu example)

```bash
sudo mkdir -p /srv/merpatmutyuny && sudo chown $USER /srv/merpatmutyuny
# copy the project files into /srv/merpatmutyuny, then:
cd /srv/merpatmutyuny
python3 -m venv venv && venv/bin/pip install -r requirements.txt
cp .env.example .env && nano .env        # set secret key, domain
set -a && . ./.env && set +a
venv/bin/python manage.py migrate
venv/bin/python manage.py seed_initial
venv/bin/python manage.py collectstatic --noinput
venv/bin/python manage.py createsuperuser
sudo chown -R www-data:www-data /srv/merpatmutyuny

sudo cp deploy/gunicorn.service /etc/systemd/system/merpatmutyuny.service
sudo systemctl enable --now merpatmutyuny
sudo cp deploy/nginx.conf /etc/nginx/sites-available/merpatmutyuny
sudo ln -s /etc/nginx/sites-available/merpatmutyuny /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d merpatmutyuny.am -d www.merpatmutyuny.am   # HTTPS
sudo crontab -u www-data -e     # paste the line from deploy/crontab.txt
```

Generate a secret key with:
`python3 -c "import secrets;print(secrets.token_urlsafe(50))"`

**Back up** by copying `db.sqlite3`. It contains everything the editor entered.

## Notes

* Videos play inside the site through YouTube's embed player. They only play
  when the site is opened through a domain (http/https), not as a local file.
  The project also sets `SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"`.
  Without it, YouTube shows Error 153. Do not remove it.
* `python manage.py import_youtube --dry-run` shows what would be imported
  without saving anything.
* `/api/catalog/` returns all published content as JSON, ready for a future
  mobile app or other sites.
