"""Check the YouTube channel for new uploads and add them to the database.

    python manage.py import_youtube            # normal run (put this in cron, hourly)
    python manage.py import_youtube --dry-run  # only show what would be added
    python manage.py import_youtube --file feed.xml   # test with a saved feed

Uses YouTube's public RSS feed (latest 15 uploads) - no API key needed.
New videos get the status from settings.YOUTUBE_IMPORT_STATUS ("review" by
default), so the editor can choose the section and publish them in /admin.
"""
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime

from django.conf import settings
from django.core.management.base import BaseCommand
from django.db.models import Max

from catalog.models import Episode, Section, Short, Source
from catalog.utils import suggest_section

FEED = "https://www.youtube.com/feeds/videos.xml?channel_id={}"
NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015"}
UA = {"User-Agent": "Mozilla/5.0 (MerPatmutyuny site importer)"}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def is_short(video_id: str) -> bool:
    """YouTube serves /shorts/<id> directly for Shorts and redirects normal videos."""
    opener = urllib.request.build_opener(_NoRedirect)
    req = urllib.request.Request(f"https://www.youtube.com/shorts/{video_id}", method="HEAD", headers=UA)
    try:
        return opener.open(req, timeout=10).status == 200
    except urllib.error.HTTPError:
        return False
    except Exception:
        return False


def parse_feed(xml_bytes: bytes):
    root = ET.fromstring(xml_bytes)
    for entry in root.findall("a:entry", NS):
        vid = entry.findtext("yt:videoId", namespaces=NS)
        title = (entry.findtext("a:title", namespaces=NS) or "").strip()
        published = entry.findtext("a:published", namespaces=NS)
        link = entry.find("a:link", NS)
        href = link.get("href", "") if link is not None else ""
        when = datetime.fromisoformat(published.replace("Z", "+00:00")) if published else None
        yield {"id": vid, "title": title, "published": when, "short_hint": "/shorts/" in href}


class Command(BaseCommand):
    help = "Import new uploads from the YouTube channel"

    def add_arguments(self, parser):
        parser.add_argument("--dry-run", action="store_true")
        parser.add_argument("--file", help="Read the feed from a local XML file (for testing)")
        parser.add_argument("--no-shorts-check", action="store_true",
                            help="Do not ask YouTube whether a video is a Short")

    def handle(self, *args, **o):
        if o["file"]:
            data = open(o["file"], "rb").read()
        else:
            url = FEED.format(settings.YOUTUBE_CHANNEL_ID)
            data = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20).read()

        known = set(Episode.objects.values_list("youtube_id", flat=True)) | set(
            Short.objects.values_list("youtube_id", flat=True)
        )
        sections = list(Section.objects.all())
        status = settings.YOUTUBE_IMPORT_STATUS
        next_no = (Episode.objects.aggregate(m=Max("number"))["m"] or 0) + 1

        # oldest first, so episode numbers grow in upload order
        entries = sorted(parse_feed(data), key=lambda e: e["published"] or datetime.min)
        added = []
        for e in entries:
            if not e["id"] or e["id"] in known:
                continue
            short = e["short_hint"] or (not o["no_shorts_check"] and not o["file"] and is_short(e["id"]))
            if short:
                if not o["dry_run"]:
                    Short.objects.create(youtube_id=e["id"], title=e["title"], status=status,
                                         published_at=e["published"], source=Source.AUTO)
                added.append(f"SHORT  {e['id']}  {e['title']}")
            else:
                sec = suggest_section(e["title"], sections)
                if not o["dry_run"]:
                    Episode.objects.create(youtube_id=e["id"], title=e["title"], number=next_no,
                                           section=sec, status=status,
                                           published_at=e["published"], source=Source.AUTO)
                added.append(f"№{next_no:<4} {e['id']}  [{sec.slug if sec else '—'}]  {e['title']}")
                next_no += 1

        if added:
            self.stdout.write(self.style.SUCCESS(f"{'Would add' if o['dry_run'] else 'Added'} {len(added)}:"))
            for line in added:
                self.stdout.write("  " + line)
        else:
            self.stdout.write("No new videos.")
