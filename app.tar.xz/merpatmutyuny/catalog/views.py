from django.db.models import Count, Q
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.cache import cache_page
from django.conf import settings

from .models import Episode, Section, Short, Status


def catalog_data():
    """Everything the public site needs, as plain JSON-ready data."""
    sections = Section.objects.annotate(
        n=Count("episodes", filter=Q(episodes__status=Status.PUBLISHED))
    ).order_by("order", "name")
    episodes = Episode.objects.filter(status=Status.PUBLISHED).select_related("section")
    shorts = Short.objects.filter(status=Status.PUBLISHED)
    return {
        "channel": settings.YOUTUBE_CHANNEL_ID,
        "sections": [
            {"slug": s.slug, "name": s.name, "tagline": s.tagline, "count": s.n}
            for s in sections
        ],
        "episodes": [
            {
                "id": e.youtube_id,
                "n": e.number,
                "t": e.title,
                "c": e.section.slug if e.section else "",
                "f": e.is_featured,
            }
            for e in episodes
        ],
        "shorts": [{"id": s.youtube_id, "t": s.title} for s in shorts],
    }


def home(request):
    return render(request, "catalog/index.html", {"catalog": catalog_data()})


@cache_page(60)
def api_catalog(request):
    resp = JsonResponse(catalog_data(), json_dumps_params={"ensure_ascii": False})
    resp["Access-Control-Allow-Origin"] = "*"
    return resp
