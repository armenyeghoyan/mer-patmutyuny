from django import forms
from django.contrib import admin, messages
from django.db.models import Count
from django.utils.html import format_html

from .models import Episode, Section, Short, Status
from .utils import extract_youtube_id, suggest_section

admin.site.site_header = "Մեր Պատմությունը — կառավարում"
admin.site.site_title = "Մեր Պատմությունը"
admin.site.index_title = "Կայքի բովանդակություն"


class YouTubeField(forms.CharField):
    """Lets the editor paste a whole YouTube link; stores only the 11-char ID."""

    def __init__(self, **kw):
        kw.setdefault("max_length", 300)
        kw.setdefault("label", "YouTube հղում կամ ID")
        kw.setdefault("help_text", "Տեղադրեք հղումը, օր.՝ https://www.youtube.com/watch?v=… կամ /shorts/…")
        super().__init__(**kw)

    def clean(self, value):
        value = super().clean(value)
        vid = extract_youtube_id(value)
        if not vid:
            raise forms.ValidationError("Սա YouTube-ի հղում չէ։")
        return vid


class EpisodeForm(forms.ModelForm):
    youtube_id = YouTubeField()

    class Meta:
        model = Episode
        fields = "__all__"


class ShortForm(forms.ModelForm):
    youtube_id = YouTubeField()

    class Meta:
        model = Short
        fields = "__all__"


def thumb(obj, w=120, vertical=False):
    h = int(w * 16 / 9) if vertical else int(w * 9 / 16)
    return format_html(
        '<a href="https://www.youtube.com/watch?v={}" target="_blank" rel="noopener">'
        '<img src="{}" style="width:{}px;height:{}px;object-fit:cover;border-radius:8px"></a>',
        obj.youtube_id, obj.thumbnail, w, h,
    )


@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "order", "episode_count")
    list_editable = ("order",)
    prepopulated_fields = {"slug": ("name",)}

    def get_queryset(self, request):
        return super().get_queryset(request).annotate(n=Count("episodes")).order_by("order", "name")

    @admin.display(description="Դրվագներ", ordering="n")
    def episode_count(self, obj):
        return obj.n


@admin.register(Episode)
class EpisodeAdmin(admin.ModelAdmin):
    form = EpisodeForm
    list_display = ("preview", "number", "title", "section", "status", "is_featured", "priority", "source")
    list_display_links = ("preview", "title")
    list_editable = ("section", "status", "is_featured", "priority")
    list_filter = ("status", "section", "is_featured", "source")
    search_fields = ("title", "youtube_id")
    list_per_page = 50
    actions = ("publish", "hide", "auto_section")
    readonly_fields = ("big_preview", "created_at", "updated_at")
    fieldsets = (
        (None, {"fields": ("youtube_id", "big_preview", "title", "number")}),
        ("Որտեղ ցուցադրել", {"fields": ("section", "status", "is_featured", "priority")}),
        ("Տեղեկություն", {"classes": ("collapse",), "fields": ("published_at", "source", "created_at", "updated_at")}),
    )

    @admin.display(description="")
    def preview(self, obj):
        return thumb(obj)

    @admin.display(description="Նախադիտում")
    def big_preview(self, obj):
        return thumb(obj, 320) if obj.pk else "—"

    def get_changeform_initial_data(self, request):
        data = super().get_changeform_initial_data(request)
        last = Episode.objects.exclude(number=None).order_by("-number").first()
        data.setdefault("number", (last.number + 1) if last else 1)
        return data

    @admin.action(description="Հրապարակել ընտրվածները")
    def publish(self, request, qs):
        n = qs.update(status=Status.PUBLISHED)
        self.message_user(request, f"Հրապարակվեց {n} դրվագ։", messages.SUCCESS)

    @admin.action(description="Թաքցնել ընտրվածները")
    def hide(self, request, qs):
        n = qs.update(status=Status.HIDDEN)
        self.message_user(request, f"Թաքցվեց {n} դրվագ։", messages.SUCCESS)

    @admin.action(description="Ավտոմատ առաջարկել բաժին (բանալի բառերով)")
    def auto_section(self, request, qs):
        sections = list(Section.objects.all())
        n = 0
        for ep in qs:
            s = suggest_section(ep.title, sections)
            if s and s != ep.section:
                ep.section = s
                ep.save(update_fields=["section"])
                n += 1
        self.message_user(request, f"Բաժինը փոխվեց {n} դրվագի համար։", messages.SUCCESS)


@admin.register(Short)
class ShortAdmin(admin.ModelAdmin):
    form = ShortForm
    list_display = ("preview", "title", "status", "priority", "source")
    list_display_links = ("preview", "title")
    list_editable = ("status", "priority")
    list_filter = ("status", "source")
    search_fields = ("title", "youtube_id")

    @admin.display(description="")
    def preview(self, obj):
        return thumb(obj, 60, vertical=True)
