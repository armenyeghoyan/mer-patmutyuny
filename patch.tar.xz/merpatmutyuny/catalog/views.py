from django.db.models import Count, Q
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.cache import cache_page
from django.conf import settings
from django.urls import reverse

from . import seo
from .models import Episode, Section, Short, Status


def catalog_data():
    """Everything the public site needs, as plain JSON-ready data."""
    sections = Section.objects.annotate(
        n=Count("episodes", filter=Q(episodes__status=Status.PUBLISHED))
    ).order_by("order", "name")
    episodes = Episode.objects.filter(status=Status.PUBLISHED).select_related("section")
    shorts = Short.objects.filter(status=Status.PUBLISHED)
    return {
        "channel": settings.YOUTUBE_CHANNEL_ID,
        "sections": [
            {"slug": s.slug, "name": s.name, "tagline": s.tagline, "count": s.n}
            for s in sections
        ],
        "episodes": [
            {
                "id": e.youtube_id,
                "n": e.number,
                "t": e.title,
                "c": e.section.slug if e.section else "",
                "f": e.is_featured,
            }
            for e in episodes
        ],
        "shorts": [{"id": s.youtube_id, "t": s.title} for s in shorts],
    }


def _published():
    return Episode.objects.filter(status=Status.PUBLISHED).select_related("section")


def home(request):
    cat = catalog_data()
    eps = list(_published())
    latest = eps[:12]
    base = seo.site_url(request)
    nodes = seo.org_nodes(request, settings.YOUTUBE_CHANNEL_ID)
    nodes.append({
        "@type": "ItemList", "name": "Նոր դրվագներ",
        "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "url": seo.abs_url(request, "episode", e.youtube_id), "name": e.title}
            for i, e in enumerate(latest)
        ],
    })
    nodes += [seo.video_ld(request, e) for e in latest[:6]]
    sections = list(Section.objects.all())
    by_sec = {s.pk: [] for s in sections}
    for e in eps:
        if e.section_id in by_sec:
            by_sec[e.section_id].append(e)
    return render(request, "catalog/index.html", {
        "catalog": cat,
        "seo_title": seo.HOME_TITLE,
        "seo_desc": seo.HOME_DESC,
        "canonical": base + "/",
        "og_image": seo.thumb(latest[0].youtube_id) if latest else "",
        "jsonld": seo.dumps(*nodes),
        "index_sections": [(s, by_sec[s.pk]) for s in sections if by_sec[s.pk]],
    })


def episode(request, yid):
    e = get_object_or_404(_published(), youtube_id=yid)
    related = [x for x in _published().filter(section=e.section).exclude(pk=e.pk)[:6]] if e.section else []
    nxt = _published().filter(number__gt=e.number).order_by("number").first() if e.number else None
    prev = _published().filter(number__lt=e.number).order_by("-number").first() if e.number else None
    crumbs = [("Գլխավոր", seo.site_url(request) + "/")]
    if e.section:
        crumbs.append((e.section.name, seo.abs_url(request, "section", e.section.slug)))
    crumbs.append((e.title, seo.abs_url(request, "episode", e.youtube_id)))
    nodes = seo.org_nodes(request, settings.YOUTUBE_CHANNEL_ID) + [seo.video_ld(request, e), seo.breadcrumb(request, crumbs)]
    return render(request, "catalog/episode.html", {
        "e": e, "related": related, "prev": prev, "next": nxt, "crumbs": crumbs,
        "seo_title": seo.ep_title(e), "seo_desc": seo.ep_desc(e),
        "canonical": seo.abs_url(request, "episode", e.youtube_id),
        "og_image": seo.thumb(e.youtube_id), "og_type": "video.other",
        "jsonld": seo.dumps(*nodes), "channel": settings.YOUTUBE_CHANNEL_ID,
    })


def section(request, slug):
    sec = get_object_or_404(Section, slug=slug)
    eps = list(_published().filter(section=sec))
    if not eps:
        raise Http404
    crumbs = [("Գլխավոր", seo.site_url(request) + "/"), (sec.name, seo.abs_url(request, "section", sec.slug))]
    nodes = seo.org_nodes(request, settings.YOUTUBE_CHANNEL_ID) + [
        seo.breadcrumb(request, crumbs),
        {"@type": "ItemList", "name": sec.name, "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "url": seo.abs_url(request, "episode", e.youtube_id), "name": e.title}
            for i, e in enumerate(eps)]},
    ]
    desc = f"{sec.name}. {sec.tagline} " if sec.tagline else f"{sec.name}. "
    desc += f"{len(eps)} դրվագ «{seo.SITE_NAME}» հեռուստանախագծից՝ դիտեք առցանց։"
    return render(request, "catalog/section.html", {
        "sec": sec, "episodes": eps, "crumbs": crumbs,
        "seo_title": f"{sec.name} — {len(eps)} դրվագ | {seo.SITE_NAME}", "seo_desc": desc[:300],
        "canonical": seo.abs_url(request, "section", sec.slug),
        "og_image": seo.thumb(eps[0].youtube_id), "jsonld": seo.dumps(*nodes),
        "channel": settings.YOUTUBE_CHANNEL_ID,
    })


def robots(request):
    body = "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\n\nSitemap: " + seo.site_url(request) + "/sitemap.xml\n"
    return HttpResponse(body, content_type="text/plain; charset=utf-8")


def sitemap(request):
    from xml.sax.saxutils import escape
    base = seo.site_url(request)
    eps = list(_published())
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">']
    last = max((e.updated_at for e in eps), default=None)
    out.append(f"<url><loc>{base}/</loc>" + (f"<lastmod>{last.date().isoformat()}</lastmod>" if last else "") + "<changefreq>weekly</changefreq><priority>1.0</priority></url>")
    secs = {}
    for e in eps:
        if e.section:
            secs.setdefault(e.section.slug, []).append(e)
    for slug, items in secs.items():
        lm = max(i.updated_at for i in items).date().isoformat()
        out.append(f"<url><loc>{base}{reverse('section', args=[slug])}</loc><lastmod>{lm}</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>")
    for e in eps:
        loc = f"{base}{reverse('episode', args=[e.youtube_id])}"
        when = (e.published_at or e.created_at).date().isoformat()
        out.append(
            f"<url><loc>{loc}</loc><lastmod>{e.updated_at.date().isoformat()}</lastmod><priority>0.6</priority>"
            f"<video:video><video:thumbnail_loc>{seo.thumb(e.youtube_id)}</video:thumbnail_loc>"
            f"<video:title>{escape(e.title[:100])}</video:title>"
            f"<video:description>{escape(seo.ep_desc(e)[:2000])}</video:description>"
            f"<video:player_loc>https://www.youtube.com/embed/{e.youtube_id}</video:player_loc>"
            f"<video:publication_date>{when}</video:publication_date></video:video></url>")
    out.append("</urlset>")
    return HttpResponse("\n".join(out), content_type="application/xml; charset=utf-8")


@cache_page(60)
def api_catalog(request):
    resp = JsonResponse(catalog_data(), json_dumps_params={"ensure_ascii": False})
    resp["Access-Control-Allow-Origin"] = "*"
    return resp
