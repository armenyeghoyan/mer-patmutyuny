from django.db import models


class Status(models.TextChoices):
    REVIEW = "review", "Սպասում է ստուգման"
    PUBLISHED = "published", "Հրապարակված"
    HIDDEN = "hidden", "Թաքցված"


class Source(models.TextChoices):
    MANUAL = "manual", "Ձեռքով"
    AUTO = "auto", "Ավտոմատ (YouTube)"


class Section(models.Model):
    """A section of the site, e.g. Kings, Great Armenians."""

    slug = models.SlugField("Կոդ (լատինատառ)", unique=True)
    name = models.CharField("Անվանում", max_length=80)
    tagline = models.CharField("Նկարագրություն", max_length=160, blank=True)
    keywords = models.TextField(
        "Բանալի բառեր",
        blank=True,
        help_text="Ստորակետով բաժանված բառեր։ Եթե նոր տեսանյութի վերնագրում "
        "կա այս բառերից մեկը, ներմուծման ժամանակ այն կառաջարկվի այս բաժնում։",
    )
    order = models.PositiveSmallIntegerField("Հերթականություն", default=0)

    class Meta:
        ordering = ["order", "name"]
        verbose_name = "Բաժին"
        verbose_name_plural = "Բաժիններ"

    def __str__(self):
        return self.name

    def keyword_list(self):
        return [k.strip().lower() for k in self.keywords.split(",") if k.strip()]


class Episode(models.Model):
    youtube_id = models.CharField(
        "YouTube հղում կամ ID", max_length=11, unique=True,
        help_text="Կարող եք տեղադրել ամբողջական հղումը, ID-ն կառանձնացվի ինքնաշխատ։",
    )
    number = models.PositiveIntegerField("Դրվագի №", null=True, blank=True)
    title = models.CharField("Վերնագիր", max_length=300)
    section = models.ForeignKey(
        Section, verbose_name="Բաժին", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="episodes",
    )
    status = models.CharField("Կարգավիճակ", max_length=12, choices=Status.choices, default=Status.PUBLISHED)
    is_featured = models.BooleanField(
        "Գլխավոր էջում", default=False,
        help_text="Նշված դրվագները ցուցադրվում են «Նոր դրվագներ» բլոկի սկզբում։",
    )
    priority = models.IntegerField(
        "Առաջնահերթություն", default=0,
        help_text="Մեծ թիվը ցուցակում ավելի վերև է։ 0 = սովորական հերթականություն։",
    )
    published_at = models.DateTimeField("YouTube-ում հրապարակվել է", null=True, blank=True)
    source = models.CharField("Աղբյուր", max_length=8, choices=Source.choices, default=Source.MANUAL)
    created_at = models.DateTimeField("Ավելացվել է", auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-priority", "-number", "-published_at", "-created_at"]
        verbose_name = "Դրվագ"
        verbose_name_plural = "Դրվագներ"

    def __str__(self):
        return f"№{self.number} {self.title}" if self.number else self.title

    @property
    def thumbnail(self):
        return f"https://i.ytimg.com/vi/{self.youtube_id}/hqdefault.jpg"

    @property
    def url(self):
        return f"https://www.youtube.com/watch?v={self.youtube_id}"


class Short(models.Model):
    youtube_id = models.CharField("YouTube հղում կամ ID", max_length=11, unique=True)
    title = models.CharField("Վերնագիր", max_length=300)
    status = models.CharField("Կարգավիճակ", max_length=12, choices=Status.choices, default=Status.PUBLISHED)
    priority = models.IntegerField("Առաջնահերթություն", default=0)
    published_at = models.DateTimeField("YouTube-ում հրապարակվել է", null=True, blank=True)
    source = models.CharField("Աղբյուր", max_length=8, choices=Source.choices, default=Source.MANUAL)
    created_at = models.DateTimeField("Ավելացվել է", auto_now_add=True)

    class Meta:
        ordering = ["-priority", "-published_at", "-created_at"]
        verbose_name = "Short"
        verbose_name_plural = "Shorts"

    def __str__(self):
        return self.title

    @property
    def thumbnail(self):
        return f"https://i.ytimg.com/vi/{self.youtube_id}/hqdefault.jpg"
