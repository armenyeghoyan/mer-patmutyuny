/* Մեր Պատմությունը — front-end.
   All content comes from the database via the JSON block #catalog-data
   (same data as /api/catalog/). Nothing here needs editing for new episodes. */
(function () {
  "use strict";
  var DATA = JSON.parse(document.getElementById("catalog-data").textContent);
  var EPS = DATA.episodes, SHORTS = DATA.shorts, SECTIONS = DATA.sections;
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var thumb = function (id) { return "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg"; };
  var secName = {}; SECTIONS.forEach(function (s) { secName[s.slug] = s.name; });
  var playIco = '<span class="play"><svg><use href="#play"/></svg></span>';
  $("yr").textContent = new Date().getFullYear();

  /* ---------------- player (plays inside the site) ---------------- */
  var modal = $("modal"), mbox = $("mbox"), mtitle = $("mtitle"), queue = [], qi = 0;
  function playAt(i) {
    qi = (i + queue.length) % queue.length;
    var v = queue[qi];
    mbox.className = "mbox" + (v.vert ? " vert" : "");
    mbox.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/' + v.id +
      '?autoplay=1&rel=0&playsinline=1&modestbranding=1" title="' + esc(v.t) +
      '" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen" allowfullscreen></iframe>';
    mtitle.innerHTML = (v.n ? "<small>№ " + v.n + "</small>" : "") + esc(v.t);
    var multi = queue.length > 1;
    $("mprev").style.display = $("mnext").style.display = multi ? "" : "none";
  }
  function open(list, i) {
    queue = list; playAt(i);
    modal.classList.add("open"); document.body.style.overflow = "hidden";
    $("mclose").focus({ preventScroll: true });
  }
  function close() { modal.classList.remove("open"); mbox.innerHTML = ""; document.body.style.overflow = ""; }
  $("mclose").onclick = close;
  $("mprev").onclick = function () { playAt(qi - 1); };
  $("mnext").onclick = function () { playAt(qi + 1); };
  modal.addEventListener("click", function (e) { if (e.target === modal) close(); });
  addEventListener("keydown", function (e) {
    if (!modal.classList.contains("open")) return;
    if (e.key === "Escape") close();
    if (e.key === "ArrowRight" && queue.length > 1) playAt(qi + 1);
    if (e.key === "ArrowLeft" && queue.length > 1) playAt(qi - 1);
  });
  function openEpisode(id, list) {
    list = list || EPS;
    var i = list.findIndex(function (v) { return v.id === id; });
    open(list, Math.max(0, i));
  }

  /* ---------------- hero ---------------- */
  var latest = EPS.filter(function (e) { return e.f; }).concat(EPS.filter(function (e) { return !e.f; })).slice(0, 6);
  if (latest[0]) {
    $("newchipText").textContent = (latest[0].n ? "№" + latest[0].n + " · " : "") + latest[0].t;
    $("newchip").onclick = $("heroPlay").onclick = function () { openEpisode(latest[0].id, latest); };
  } else { $("newchip").hidden = true; }

  /* ---------------- featured + up next ---------------- */
  var cur = 0, timer = null, started = 0, DUR = 7000, featVisible = false;
  var up = $("upnext");
  up.innerHTML = latest.map(function (v, i) {
    return '<button type="button" role="listitem" data-i="' + i + '"><img loading="lazy" src="' + thumb(v.id) + '" alt=""><span><small>' +
      (v.n ? "№ " + v.n + " · " : "") + esc(secName[v.c] || "") + '</small><span>' + esc(v.t) + "</span></span></button>";
  }).join("");
  function show(i) {
    cur = i; var v = latest[i]; if (!v) return;
    $("featBg").style.backgroundImage = "url('" + thumb(v.id).replace("hqdefault", "maxresdefault") + "'), url('" + thumb(v.id) + "')";
    $("featTag").textContent = (v.n ? "Դրվագ № " + v.n + " · " : "") + (secName[v.c] || "");
    $("featTitle").textContent = v.t;
    Array.prototype.forEach.call(up.children, function (b, k) { b.classList.toggle("on", k === i); });
    started = performance.now();
  }
  up.addEventListener("click", function (e) { var b = e.target.closest("button"); if (b) show(+b.dataset.i); });
  $("featMain").onclick = function () { openEpisode(latest[cur].id, latest); };
  (function tick(t) {
    requestAnimationFrame(tick);
    if (reduce || !featVisible || modal.classList.contains("open")) { started = performance.now() - (parseFloat($("progress").style.width) || 0) / 100 * DUR; return; }
    var p = Math.min(1, (t - started) / DUR);
    $("progress").style.width = (p * 100) + "%";
    if (p >= 1) show((cur + 1) % latest.length);
  })(performance.now());
  new IntersectionObserver(function (e) { featVisible = e[0].isIntersecting; }, { threshold: .35 }).observe($("featMain"));
  show(0);

  /* ---------------- stats ---------------- */
  function countUp(el, to) {
    if (reduce) { el.textContent = to; return; }
    var t0 = null;
    (function step(t) { t0 = t0 || t; var p = Math.min(1, (t - t0) / 1600); el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); })(performance.now());
  }
  var statsSeen = false;
  new IntersectionObserver(function (e) {
    if (e[0].isIntersecting && !statsSeen) { statsSeen = true; countUp($("statEps"), EPS.length); countUp($("statSec"), SECTIONS.length); }
  }, { threshold: .4 }).observe($("facts"));

  /* ---------------- sections bento ---------------- */
  var bySec = {}; EPS.forEach(function (e) { (bySec[e.c] = bySec[e.c] || []).push(e); });
  var cells = SECTIONS.slice().sort(function (a, b) { return b.count - a.count; });
  $("bento").innerHTML = cells.map(function (s, i) {
    var pics = (bySec[s.slug] || []).slice(0, i === 0 ? 9 : 3);
    return '<button type="button" class="cell rv' + (i === 0 ? " big" : "") + '" data-cat="' + esc(s.slug) + '">' +
      '<span class="mosaic">' + pics.map(function (p) { return '<i style="background-image:url(\'' + thumb(p.id) + '\')"></i>'; }).join("") + "</span>" +
      '<span class="cnt gold">' + s.count + "</span>" +
      "<span><h3>" + esc(s.name) + "</h3><p>" + esc(s.tagline) + '</p><span class="go">Դիտել դրվագները →</span></span></button>';
  }).join("") +
    '<a class="cell shorts-cell rv" href="#shorts"><span class="cnt gold">' + SHORTS.length + "</span><span><h3>Shorts</h3><p>Պատմություն՝ մեկ րոպեում</p><span class=\"go\">Դիտել →</span></span></a>";
  $("footSections").innerHTML = SECTIONS.map(function (s) { return '<li><a href="#library" data-cat="' + esc(s.slug) + '">' + esc(s.name) + "</a></li>"; }).join("");

  /* ---------------- library ---------------- */
  var grid = $("grid"), q = $("q"), more = $("more"), seg = $("seg"), pill = $("segPill");
  var cat = "all", shown = 12, filtered = EPS;
  seg.insertAdjacentHTML("beforeend", [{ slug: "all", name: "Բոլորը", count: EPS.length }].concat(SECTIONS).map(function (s) {
    return '<button type="button" data-k="' + esc(s.slug) + '">' + esc(s.name) + "<i>" + s.count + "</i></button>";
  }).join(""));
  function movePill() {
    var b = seg.querySelector("button.on"); if (!b) return;
    pill.style.width = b.offsetWidth + "px"; pill.style.transform = "translateX(" + (b.offsetLeft) + "px)";
  }
  function setCat(k) {
    cat = k; shown = 12;
    seg.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.k === k); });
    movePill(); render();
  }
  function render() {
    var s = q.value.trim().toLowerCase();
    filtered = EPS.filter(function (v) {
      return (cat === "all" || v.c === cat) && (!s || v.t.toLowerCase().indexOf(s) > -1 || String(v.n) === s.replace("№", "").trim());
    });
    grid.innerHTML = filtered.slice(0, shown).map(function (v) {
      return '<button class="ep" type="button" data-id="' + v.id + '"><span class="th"><img loading="lazy" src="' + thumb(v.id) + '" alt="">' + playIco +
        '</span><span class="meta"><span class="no">' + (v.n || "") + "</span><span><h3>" + esc(v.t) + '</h3><span class="tag">' + esc(secName[v.c] || "") + "</span></span></span></button>";
    }).join("") || '<p class="empty">Ոչինչ չի գտնվել։</p>';
    more.style.display = filtered.length > shown ? "" : "none";
  }
  seg.addEventListener("click", function (e) { var b = e.target.closest("button"); if (b) setCat(b.dataset.k); });
  q.addEventListener("input", function () { shown = 12; render(); });
  more.onclick = function () { shown += 12; render(); };
  grid.addEventListener("click", function (e) { var b = e.target.closest(".ep"); if (b) openEpisode(b.dataset.id, filtered); });
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-cat]"); if (!b) return;
    e.preventDefault(); setCat(b.dataset.cat); q.value = ""; render();
    $("library").scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
  });
  addEventListener("resize", movePill);
  if (document.fonts) document.fonts.ready.then(movePill);
  setCat("all");

  /* ---------------- shorts ---------------- */
  var shortList = SHORTS.map(function (s) { return { id: s.id, t: s.t, vert: true }; });
  $("shortTrack").innerHTML = SHORTS.map(function (s, i) {
    return '<button class="short" type="button" data-i="' + i + '"><img loading="lazy" src="https://i.ytimg.com/vi/' + s.id + '/oar2.jpg" onerror="this.onerror=null;this.src=\'' + thumb(s.id) + '\'" alt=""><span>' + esc(s.t) + "</span></button>";
  }).join("");
  $("shortTrack").addEventListener("click", function (e) { var b = e.target.closest(".short"); if (b) open(shortList, +b.dataset.i); });

  /* ---------------- paddles ---------------- */
  document.querySelectorAll(".paddles button").forEach(function (b) {
    b.addEventListener("click", function () {
      var t = $(b.dataset.t), c = t.firstElementChild; if (!c) return;
      t.scrollBy({ left: (c.offsetWidth + 18) * Number(b.dataset.d), behavior: reduce ? "auto" : "smooth" });
    });
  });

  /* ---------------- reveal + nav highlight ---------------- */
  var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }); }, { threshold: .1 });
  document.querySelectorAll(".rv").forEach(function (el) { io.observe(el); });
  var links = document.querySelectorAll("#navlinks a");
  var navIO = new IntersectionObserver(function (es) {
    es.forEach(function (e) { if (e.isIntersecting) links.forEach(function (a) { a.classList.toggle("on", a.getAttribute("href") === "#" + e.target.id); }); });
  }, { rootMargin: "-45% 0px -50% 0px" });
  ["featured", "sections", "library", "shorts", "timeline"].forEach(function (id) { navIO.observe($(id)); });

  /* ---------------- manifesto: words light up while scrolling ---------------- */
  var mf = $("manifesto"), words = [], txt = mf.textContent, keys = ["պատմությունը", "ժառանգությունը", "մեծերին", "մշակույթը։"];
  mf.textContent = "";
  txt.split(" ").forEach(function (w, i, a) {
    var s = document.createElement("span"); s.className = "w" + (keys.indexOf(w.replace(/[,«»]/g, "")) > -1 ? " k" : ""); s.textContent = w;
    words.push(s); mf.appendChild(s); if (i < a.length - 1) mf.appendChild(document.createTextNode(" "));
  });
  function light() {
    var r = mf.getBoundingClientRect(), vh = innerHeight;
    var p = Math.min(1, Math.max(0, (vh * .85 - r.top) / (r.height + vh * .35))), n = Math.round(p * words.length);
    for (var i = 0; i < words.length; i++) words[i].classList.toggle("on", i < n);
  }
  if (!reduce) { addEventListener("scroll", light, { passive: true }); light(); }

  /* ---------------- hero: golden dust ---------------- */
  (function dust() {
    var c = $("dust"), x = c.getContext("2d"), ps = [], W, H, dpr = Math.min(devicePixelRatio || 1, 2);
    function size() { W = c.clientWidth; H = c.clientHeight; c.width = W * dpr; c.height = H * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0); }
    size(); addEventListener("resize", size);
    for (var i = 0; i < 70; i++) ps.push({ x: Math.random(), y: Math.random(), r: Math.random() * 1.6 + .3, s: Math.random() * .00025 + .00008, a: Math.random() * .6 + .15, p: Math.random() * 6.28 });
    var vis = true; new IntersectionObserver(function (e) { vis = e[0].isIntersecting; }).observe(c);
    (function loop(t) {
      requestAnimationFrame(loop); if (!vis) return;
      x.clearRect(0, 0, W, H);
      ps.forEach(function (p) {
        if (!reduce) { p.y -= p.s; if (p.y < -.02) { p.y = 1.02; p.x = Math.random(); } }
        x.globalAlpha = p.a * (.6 + .4 * Math.sin(t / 900 + p.p));
        x.fillStyle = "#E9C27A"; x.beginPath(); x.arc(p.x * W, p.y * H, p.r, 0, 6.283); x.fill();
      });
    })(0);
  })();

  /* ---------------- hero: polished gold eternity sign (three.js) ---------------- */
  var stage = $("stage");
  try {
    if (!window.THREE) throw 0;
    var R = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    R.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    R.outputEncoding = THREE.sRGBEncoding; R.toneMapping = THREE.ACESFilmicToneMapping; R.toneMappingExposure = 1.1;
    stage.appendChild(R.domElement);
    var S = new THREE.Scene(), C = new THREE.PerspectiveCamera(30, 1, .1, 100); C.position.set(0, 0, 11);
    var env = new THREE.Scene();
    env.add(new THREE.Mesh(new THREE.SphereGeometry(20, 32, 16), new THREE.MeshBasicMaterial({ color: 0x0c0a08, side: THREE.BackSide })));
    function box(w, h, px, py, pz, col) { var m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide })); m.position.set(px, py, pz); m.lookAt(0, 0, 0); env.add(m); }
    box(14, 4, 0, 10, 4, 0xfff6e8); box(4, 12, -11, 0, 4, 0xffe6c4); box(3, 10, 11, 1, 2, 0xffd9a8); box(16, 3, 0, -9, 6, 0x7a5a32); box(6, 6, 0, 2, -12, 0xffffff);
    S.environment = new THREE.PMREMGenerator(R).fromScene(env, 0.035).texture;
    var gold = new THREE.MeshPhysicalMaterial({ color: 0xE6B45E, metalness: 1, roughness: .2, clearcoat: .7, clearcoatRoughness: .08 });
    var G = new THREE.Group();
    for (var k = 0; k < 8; k++) {
      var th = -k * Math.PI / 4, pts = [];
      for (var j = 0; j <= 60; j++) { var a = Math.PI - Math.PI * j / 60; pts.push(new THREE.Vector3(Math.cos(th) + Math.cos(th + a), Math.sin(th) + Math.sin(th + a), 0)); }
      G.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 90, .09, 20, false), gold));
      var tip = new THREE.Mesh(new THREE.SphereGeometry(.09, 20, 20), gold); tip.position.copy(pts[pts.length - 1]); G.add(tip);
    }
    G.add(new THREE.Mesh(new THREE.SphereGeometry(.18, 32, 32), gold));
    G.add(new THREE.Mesh(new THREE.TorusGeometry(2.28, .045, 20, 200), gold));
    G.add(new THREE.Mesh(new THREE.TorusGeometry(2.55, .018, 12, 200), gold));
    S.add(G);
    var cv = document.createElement("canvas"); cv.width = cv.height = 256;
    var cx = cv.getContext("2d"), gr = cx.createRadialGradient(128, 128, 0, 128, 128, 128);
    gr.addColorStop(0, "rgba(233,180,94,.4)"); gr.addColorStop(1, "rgba(233,180,94,0)"); cx.fillStyle = gr; cx.fillRect(0, 0, 256, 256);
    var glow = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(cv), transparent: true, depthWrite: false }));
    glow.position.z = -1.2; S.add(glow);
    function size() { var w = stage.clientWidth, h = stage.clientHeight; R.setSize(w, h, false); R.domElement.style.width = "100%"; R.domElement.style.height = "100%"; C.aspect = w / h; C.position.z = w / h < .8 ? 14 : 11; C.updateProjectionMatrix(); }
    size(); addEventListener("resize", size);
    var mx = 0, my = 0, smx = 0, smy = 0;
    addEventListener("pointermove", function (e) { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; }, { passive: true });
    var vis = true; new IntersectionObserver(function (e) { vis = e[0].isIntersecting; }).observe(stage);
    var clk = new THREE.Clock(), intro = reduce ? 1 : 0;
    (function loop() {
      requestAnimationFrame(loop); if (!vis) return;
      var t = clk.getElapsedTime();
      if (intro < 1) intro = Math.min(1, intro + .008);
      var e = 1 - Math.pow(1 - intro, 4), r = stage.getBoundingClientRect(), sp = Math.min(1, Math.max(0, -r.top / r.height));
      smx += (mx - smx) * .05; smy += (my - smy) * .05;
      G.rotation.z = reduce ? 0 : t * .1;
      G.rotation.y = (1 - e) * -1.6 + smx * .6 + sp * 1.2;
      G.rotation.x = -.2 + smy * .35 + sp * .3;
      G.scale.setScalar(.8 + .2 * e);
      G.position.y = (1 - e) * -.6 + Math.sin(t * .8) * .06;
      R.render(S, C);
    })();
  } catch (err) { document.body.classList.add("no-webgl"); }
})();
