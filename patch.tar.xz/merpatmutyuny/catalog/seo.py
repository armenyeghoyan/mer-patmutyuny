"""Search-engine helpers: absolute URLs, descriptions, JSON-LD structured data."""
import json

from django.conf import settings
from django.urls import reverse

SITE_NAME = "Մեր Պատմությունը"
HOME_TITLE = "Մեր Պատմությունը — հայոց պատմության հեռուստանախագիծ"
HOME_DESC = (
    "«Մեր Պատմությունը» հեռուստանախագիծը ներկայացնում է հայոց պատմությունը, "
    "պատմական ժառանգությունը, հայ մեծերին, վանքերն ու մշակույթը։ "
    "Դիտեք բոլոր դրվագները առցանց՝ նոր դրվագ ամեն շաբաթ։"
)


def site_url(request):
    return settings.SITE_URL or f"{request.scheme}://{request.get_host()}"


def abs_url(request, name, *args):
    return site_url(request) + reverse(name, args=args)


def ep_title(e):
    n = f"Դրվագ № {e.number} · " if e.number else ""
    return f"{e.title} | {n}{SITE_NAME}"[:160]


def ep_desc(e):
    sec = f" Բաժին՝ {e.section.name}։" if e.section else ""
    n = f" (դրվագ № {e.number})" if e.number else ""
    return f"{e.title}{n} — «{SITE_NAME}» հեռուստանախագիծ։{sec} Դիտեք առցանց։"[:300]


def thumb(yid, big=True):
    return f"https://i.ytimg.com/vi/{yid}/{'maxresdefault' if big else 'hqdefault'}.jpg"


def video_ld(request, e):
    d = {
        "@type": "VideoObject",
        "name": e.title,
        "description": ep_desc(e),
        "thumbnailUrl": [thumb(e.youtube_id), thumb(e.youtube_id, False)],
        "embedUrl": f"https://www.youtube.com/embed/{e.youtube_id}",
        "url": abs_url(request, "episode", e.youtube_id),
        "inLanguage": "hy",
        "isFamilyFriendly": True,
        "publisher": {"@id": site_url(request) + "/#org"},
    }
    when = e.published_at or e.created_at
    if when:
        d["uploadDate"] = when.date().isoformat()
    return d


def dumps(*nodes):
    """JSON-LD safe to put inside a <script> tag."""
    data = {"@context": "https://schema.org", "@graph": list(nodes)}
    s = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return s.replace("</", "<\\/")


def org_nodes(request, channel):
    base = site_url(request)
    return [
        {
            "@type": "Organization", "@id": base + "/#org", "name": SITE_NAME, "url": base + "/",
            "sameAs": [f"https://www.youtube.com/channel/{channel}"],
            "logo": base + "/static/img/icon.svg",
        },
        {
            "@type": "WebSite", "@id": base + "/#site", "name": SITE_NAME, "url": base + "/",
            "inLanguage": "hy", "publisher": {"@id": base + "/#org"},
            "potentialAction": {
                "@type": "SearchAction",
                "target": {"@type": "EntryPoint", "urlTemplate": base + "/?q={search_term_string}#library"},
                "query-input": "required name=search_term_string",
            },
        },
    ]


def breadcrumb(request, items):
    return {
        "@type": "BreadcrumbList",
        "itemListElement": [
            {"@type": "ListItem", "position": i + 1, "name": n, "item": u} for i, (n, u) in enumerate(items)
        ],
    }
