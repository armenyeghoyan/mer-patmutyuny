from django.contrib import admin
from django.urls import path

from catalog import views

urlpatterns = [
    path("", views.home, name="home"),
    path("api/catalog/", views.api_catalog, name="api-catalog"),
    path("admin/", admin.site.urls),
]
