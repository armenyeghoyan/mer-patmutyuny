"""Fill an empty database with the sections, 149 episodes and Shorts.

    python manage.py seed_initial

Safe to run again: existing records (matched by YouTube ID / slug) are kept.
"""
import json
from pathlib import Path

from django.core.management.base import BaseCommand

from catalog.models import Episode, Section, Short

DATA = Path(__file__).resolve().parents[2] / "data" / "initial.json"


class Command(BaseCommand):
    help = "Load the initial sections, episodes and Shorts"

    def handle(self, *args, **opts):
        data = json.loads(DATA.read_text(encoding="utf-8"))
        sections = {}
        for s in data["sections"]:
            obj, _ = Section.objects.get_or_create(
                slug=s["slug"],
                defaults={k: s[k] for k in ("name", "tagline", "order", "keywords")},
            )
            sections[obj.slug] = obj

        new_eps = 0
        for e in data["episodes"]:
            _, created = Episode.objects.get_or_create(
                youtube_id=e["id"],
                defaults={"number": e["n"], "title": e["t"], "section": sections.get(e["c"])},
            )
            new_eps += created

        new_sh = 0
        for i, s in enumerate(data["shorts"]):
            _, created = Short.objects.get_or_create(
                youtube_id=s["id"], defaults={"title": s["t"], "priority": len(data["shorts"]) - i}
            )
            new_sh += created

        self.stdout.write(self.style.SUCCESS(
            f"Sections: {len(sections)}, new episodes: {new_eps}, new shorts: {new_sh}"
        ))
