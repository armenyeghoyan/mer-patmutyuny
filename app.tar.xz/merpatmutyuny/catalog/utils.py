import re

_ID = r"[A-Za-z0-9_-]{11}"
_PATTERNS = [
    re.compile(rf"(?:v=|/shorts/|/embed/|/live/|youtu\.be/)({_ID})"),
    re.compile(rf"^({_ID})$"),
]


def extract_youtube_id(value: str) -> str | None:
    """Accept a full YouTube link (watch, shorts, youtu.be, embed) or a bare ID."""
    value = (value or "").strip()
    for p in _PATTERNS:
        m = p.search(value)
        if m:
            return m.group(1)
    return None


def suggest_section(title: str, sections):
    """Return the first section whose keyword appears in the title, else None."""
    t = (title or "").lower()
    for s in sections:
        if any(k in t for k in s.keyword_list()):
            return s
    return None
