from django.contrib import admin
from django.urls import path

from catalog import views

urlpatterns = [
    path("", views.home, name="home"),
    path("drvag/<str:yid>/", views.episode, name="episode"),
    path("bajin/<slug:slug>/", views.section, name="section"),
    path("sitemap.xml", views.sitemap, name="sitemap"),
    path("robots.txt", views.robots, name="robots"),
    path("api/catalog/", views.api_catalog, name="api-catalog"),
    path("admin/", admin.site.urls),
]
