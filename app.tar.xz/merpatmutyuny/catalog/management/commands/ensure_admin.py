"""Create the admin user from environment variables, if they are set.

    DJANGO_ADMIN_USER=editor DJANGO_ADMIN_PASSWORD=... python manage.py ensure_admin

Used on hosts like Render where you cannot type into a console. Does nothing
if the password variable is empty; never changes an existing user's password.
"""
import os

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Create the admin user from DJANGO_ADMIN_USER / DJANGO_ADMIN_PASSWORD"

    def handle(self, *args, **o):
        user = os.environ.get("DJANGO_ADMIN_USER", "admin")
        pwd = os.environ.get("DJANGO_ADMIN_PASSWORD", "")
        if not pwd:
            self.stdout.write("DJANGO_ADMIN_PASSWORD not set - no admin user created.")
            return
        U = get_user_model()
        if U.objects.filter(username=user).exists():
            self.stdout.write(f"Admin user '{user}' already exists.")
            return
        U.objects.create_superuser(username=user, email="", password=pwd)
        self.stdout.write(self.style.SUCCESS(f"Admin user '{user}' created."))
